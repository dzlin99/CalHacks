*Thanks for your interest in the Spotify App Remote SDK!
If you're submitting a bug, please use the following template.
If your issue is a feature request, please include your use-case so that we have all the necessary info.*

Issue found on *DATE*.

#### SDK Version: 

#### OS Version: 

#### Scope(s):

#### Steps to reproduce:
1.
2.

#### Expected behaviour:

#### Actual behaviour: